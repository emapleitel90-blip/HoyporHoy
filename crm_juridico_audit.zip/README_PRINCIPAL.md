﻿Proyecto: CRM Jurídico — Paquete para auditoría
Generado por: script local
Fecha: 2026-03-11T19:51:58.4927385-03:00
Instrucciones: Revisar archivos sensibles antes de compartir. No incluir claves ni tokens.
